$.validate({
    modules: 'security'
});