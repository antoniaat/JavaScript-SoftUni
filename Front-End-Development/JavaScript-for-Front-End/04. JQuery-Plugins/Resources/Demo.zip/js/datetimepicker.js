$('#dateInput').datetimepicker({
    timepicker: false
});
$('#timeInput').datetimepicker({
    datepicker: false
});
$('#dateTimeInput').datetimepicker();