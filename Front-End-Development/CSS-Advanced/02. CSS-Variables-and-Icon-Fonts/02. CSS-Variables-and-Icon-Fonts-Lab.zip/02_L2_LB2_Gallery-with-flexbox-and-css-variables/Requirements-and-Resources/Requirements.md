# 02. Gallery with flexbox and CSS variables

## Tasks
* Setup a **gallery.css** file and write styles
* Add **variables** and update **variables.css**
