# 03. Navigation with Icons and Variables

## Tasks
- Setup **navigation.css** and write styles
- Use **Variables** where useful and update **variables.css**
- Write **Media Queries** for mobile devices
