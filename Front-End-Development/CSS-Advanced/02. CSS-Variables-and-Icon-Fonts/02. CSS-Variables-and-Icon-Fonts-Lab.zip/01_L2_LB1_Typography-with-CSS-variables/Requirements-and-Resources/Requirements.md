# 01. Typography with CSS Variables 

## Tasks

* Setup a **typography.css** file and write the basic styles
* Setup a **variables.css** file and write the variables
* Populate the variables in **typography.css** with **fallback** values
* Include **Media Queries** for base font size
