# 02. Fancy List Animation 

## Tasks
- Create a **list of items** with icons
- **Animation** the showing of each element
- Use **animation-delay** to make the appearance of the elements **staggered**
