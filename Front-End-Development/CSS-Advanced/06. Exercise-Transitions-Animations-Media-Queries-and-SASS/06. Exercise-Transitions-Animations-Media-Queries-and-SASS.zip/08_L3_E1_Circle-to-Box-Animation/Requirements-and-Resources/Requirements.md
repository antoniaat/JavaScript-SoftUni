# 01. Circle to Square Animation

## Tasks
- Create a small circle
- Center the circle in the **viewport**
- **Animate** that circle *to a square* and *back to circle*
