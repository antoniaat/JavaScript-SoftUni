# 06. SASS for Loops and Animation Delay

## Tasks
- Create an **ul.items**
- Create a **keyframes animation** with opacity and translateY called **slideDown**
- Write a **@for loop** in SASS attaching **animation delay of 0.15s** to each consecutive **li** using nth-child selector
