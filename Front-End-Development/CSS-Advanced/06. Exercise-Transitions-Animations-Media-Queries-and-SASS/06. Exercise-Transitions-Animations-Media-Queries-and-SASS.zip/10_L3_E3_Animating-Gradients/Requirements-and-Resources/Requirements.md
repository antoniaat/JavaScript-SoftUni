# 03. Animating Gradients

## Tasks
- Create element *banner*
- Use **:before** and **:after** psuedo elements with **posiotion: absolute** to make them as big as their container
- Add different gradients on the **:before** and **:after** elements
- **Animate** between the different gradients by using **opacity** on the top most element
