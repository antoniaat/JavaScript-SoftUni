# 04 - Animating Box Shadow

## Tasks
- Setup navigation.css and write styles
- Use Variables where useful and update variables.css
- Write media queries for mobile devices
