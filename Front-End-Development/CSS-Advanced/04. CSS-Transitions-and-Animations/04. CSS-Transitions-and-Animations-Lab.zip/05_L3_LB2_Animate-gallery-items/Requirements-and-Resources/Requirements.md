# 02. Animate Gallery Elements

## Tasks
- Add **animation** to gallery elements that have finished loading
