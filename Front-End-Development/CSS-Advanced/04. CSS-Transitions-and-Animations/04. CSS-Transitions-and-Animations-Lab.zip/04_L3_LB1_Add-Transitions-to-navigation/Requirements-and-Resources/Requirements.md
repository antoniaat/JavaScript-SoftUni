# 1. Add Transitions to Navigation

## Tasks
- Animate the navigation activation using **Transitions**
- Use **Variables** for transition duration
- Animate each element with **delay**
