# 03. Animate Article on Load

## Tasks
- Animate showing **th** single post elements on page load
