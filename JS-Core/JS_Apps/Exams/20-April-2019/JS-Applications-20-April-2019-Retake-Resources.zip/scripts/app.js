const app = Sammy('#', function() {
    this.use('Handlebars', 'hbs');
    //TODO...
});

$(function(){
    app.run('');
}); 