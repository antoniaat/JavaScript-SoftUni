const app = Sammy('#rooter', function() {

this.use('Handlebars', 'hbs');

// Home
this.get('/', home.homePage);
this.get('#/home', home.homePage);
this.get('#/index', home.homePage);


// User
this.get('#/login', user.getLogin);
this.get('#/register', user.getRegister);
this.get('#/logout', user.getLogout);

this.post('#/login', user.postLogin);
this.post('#/register', user.postRegister);

// Recepies
this.get('#/shareRecepie', recepie.getShareRecepie);
this.post('#/shareRecepie', recepie.postShareRecepie);
this.get('#/view/:id', recepie.getRecepieDetails);
this.get('#/archive/:id', recepie.archiveRecepie);
this.get('#/like/:id', recepie.likeRecepie);

});

$(function(){
    app.run('#/home');
}); 