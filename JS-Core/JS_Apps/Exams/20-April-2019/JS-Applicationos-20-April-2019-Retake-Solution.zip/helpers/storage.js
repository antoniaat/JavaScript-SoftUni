const storage = function () {
    const appKey = "kid_r1GdgycYE";
    const appSecret = "943835d3e4744ea1a315b9d3f348d76b";

    const saveData = function (key, value) {
        localStorage.setItem(appKey + key, JSON.stringify(value));
    };

    const getData = function (key) {
        return localStorage.getItem(appKey + key);
    };

    const deleteData = function (key) {
        localStorage.removeItem(appKey + key);
    };

    const saveUser = function (data) {
        storage.saveData('userInfo', data);
        storage.saveData('authToken', data._kmd.authtoken);
    };

    const deleteUser = function () {
        storage.deleteData('userInfo');
        storage.deleteData('authToken');
    };

    return {
        appKey,
        appSecret,
        saveData,
        getData,
        deleteData,
        saveUser,
        deleteUser
    }
}();