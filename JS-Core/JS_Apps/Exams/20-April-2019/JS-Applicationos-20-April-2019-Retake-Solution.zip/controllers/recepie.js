const recepie = function () {

    const getShareRecepie = function (context) {

        let user = JSON.parse(storage.getData('userInfo'));
        context.names = user.firstName + " " + user.lastName;
        context.isLoggedIn = storage.getData('authToken') !== null;

        context.loadPartials({
            header: '../views/common/header.hbs',
            footer: '../views/common/footer.hbs'
        }).then(function () {
            this.partial('../views/recepie/shareRecepiePage.hbs');
        }).catch(function (err) {
            console.log(err);
        })
    };

    const postShareRecepie = function (context) {

        recepieModel.createRecepie(context.params).then(function (res) {
            responder.notify('successBox', 'You just share your recepie with the others!', true);
            context.redirect('#/home');
        }).catch(function (err) {
            console.log(err);
            responder.errorHandler(err);
        })
    };

    const getRecepieDetails = function (context) {

        recepieModel.getARecepie(context.params.id).then(function (res) {

            let user = JSON.parse(storage.getData('userInfo'));
            context.names = user.firstName + " " + user.lastName;
            context.isLoggedIn = storage.getData('authToken') !== null;
            context.isMyRecepie = res[0]._acl.creator === JSON.parse(storage.getData('userInfo'))._id;
            context.meal = res[0].meal;
            context.foodImageURL = res[0].foodImageURL;
            context.prepMethod = res[0].prepMethod;
            context.description = res[0].description;
            context.ingredients = res[0].ingredients;
            context.likesCounter = res[0].likesCounter;
            context.id = res[0]._id;

            context.loadPartials({
                header: '../views/common/header.hbs',
                footer: '../views/common/footer.hbs'
            }).then(function () {
                this.partial('../views/recepie/detailsRecepie.hbs');
            }).catch(function (err) {
                responder.errorHandler(err);
            })

        }).catch(function (err) {
            responder.errorHandler(err);
        });
    };

    const archiveRecepie = function (context) {

        recepieModel.archiveRecepie(context.params.id).then(function () {
            responder.notify('successBox', 'You just archive yours recepie.', true);
            context.redirect('#/home');
        }).catch(function (err) {
            responder.errorHandler(err);
        });
    };

    const likeRecepie = async function (context) {

        try {
            let currentRecepie = await recepieModel.getARecepie(context.params.id);

            if (currentRecepie[0].likesCounter === undefined) {
                currentRecepie[0].likesCounter = 0;
            }
            currentRecepie[0].likesCounter += 1;
            recepieModel.editRecepie(currentRecepie[0]).then(function () {
                responder.notify('successBox', 'You just like that recepie.');
                context.redirect('#/home');
            }).catch(function (err) {
                responder.errorHandler(err);
            })

        } catch (e) {
            responder.notify('errorBox', e, false);
        }
    };

    return {
        getShareRecepie,
        postShareRecepie,
        getRecepieDetails,
        archiveRecepie,
        likeRecepie
    }
}();