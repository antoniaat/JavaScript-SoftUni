const user = function () {

    const getLogin = function (context) {
        context.loadPartials({
            'header': '../views/common/header.hbs',
            'footer': '../views/common/footer.hbs'
        }).then(function () {
            this.partial('../views/user/loginPage.hbs')
        })
    };


    const getRegister = function (context) {
        context.loadPartials({
            'header': '../views/common/header.hbs',
            'footer': '../views/common/footer.hbs'
        }).then(function () {
            this.partial('../views/user/registerPage.hbs')
        })
    };


    const postLogin = function (context) {

        userModel.login(context.params).then(function (res) {
            storage.saveUser(res);
            responder.notify('successBox', 'You just logged in successfully!', true);
            context.redirect('#/home');
        }).catch(function (err) {
            console.log(err);
            responder.notify('errorBox', err.responseJSON.description, false);
        })
    };


    const postRegister = function (context) {
        let data = { ...context.params };

        if (data.password === data.repeatPassword) {
            userModel.register(data).then(function (res) {
                storage.saveUser(res);
                responder.notify('successBox', 'You just registered successfully!');
                context.redirect('#/home');
            }).catch(function (err) {
                responder.errorHandler(err);
            });
        } else {
            responder.notify('errorBox', 'The passwords should match.', true)
        }
    };

    const getLogout = function (context) {
        userModel.logout().then(function() {
            storage.deleteUser();
            responder.notify('successBox', 'You just logged out successfully!', true);
            context.redirect('#/home');
        })
    };

    return {
        getLogin,
        getRegister,
        postLogin,
        postRegister,
        getLogout
    }
}();