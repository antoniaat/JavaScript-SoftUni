const home = function () {

    const homePage =  async function (context) {
        
        let isLoggedIn = storage.getData('authToken') !== null
        context.isLoggedIn = isLoggedIn;

        if(isLoggedIn){
            let user = JSON.parse(storage.getData('userInfo'));
            context.names = user.firstName + " " + user.lastName;
            context.recepies = await recepieModel.getAllRecepies();
            console.log(context.recepies);
        }

        context.loadPartials({
            header: '../views/common/header.hbs',
            footer: '../views/common/footer.hbs',
            anonymousPage: '../views/home/anonumoysHomePage.hbs',
            loggedInPage: '../views/home/loggedInHomePage.hbs',
            recepie: '../views/recepie/recepie.hbs'
        }).then(function () {
            this.partial('../views/home/homePage.hbs')
        }).catch(function (err) {
            console.log(err);  
            responder.errorHandler(err);
        })
    };

    return {
        homePage
    }
}();