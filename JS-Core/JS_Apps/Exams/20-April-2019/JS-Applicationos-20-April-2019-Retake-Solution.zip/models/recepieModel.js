const recepieModel = function () {

    const createRecepie = function (params) {
        let data = {
            ...params,
            categoryImageURL: recepieValidator.getCurrentCategoryURL(params.category),
            likesCounter: 0,
            ingredients: params.ingredients.split(', ')
        };

        let url = `appdata/${storage.appKey}/recepies`;
        return requester.post(url, "", data);
    };

    const getAllRecepies = function () {
        let url = `appdata/${storage.appKey}/recepies`;
        return requester.get(url);
    };

    const getARecepie = function (id) {
        let url = `appdata/${storage.appKey}/recepies?query={"_id": {"$eq": "${id}"}}`;
        return requester.get(url);
    };

    const archiveRecepie = function (id) {
        let url = `appdata/${storage.appKey}/recepies/${id}`;
        return requester.del(url);
    };

    const editRecepie = function (res) {
        let url = `appdata/${storage.appKey}/recepies/${res._id}`;
        return requester.put(url, '', res)
    };

    return {
        createRecepie,
        getAllRecepies,
        getARecepie,
        archiveRecepie,
        editRecepie
    }
}();